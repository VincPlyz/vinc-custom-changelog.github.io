scoreboard players reset @p reset_attributes
scoreboard players enable @p reset_attributes

attribute @p minecraft:air_drag_modifier base reset
attribute @p minecraft:bounciness base reset
attribute @p minecraft:friction_modifier base reset