scoreboard players reset @p spawn_invisible_sulfur
scoreboard players enable @p spawn_invisible_sulfur

function triggers/spawn_invisible_sulfur with storage minecraft:item