scoreboard players reset @p all_sulfur_archetypes
scoreboard players enable @p all_sulfur_archetypes

function triggers/sulfur_archetypes with storage minecraft:item