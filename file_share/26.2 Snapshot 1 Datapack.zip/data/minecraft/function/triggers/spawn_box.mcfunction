$execute at @p positioned ~-1 ~-1 ~-1 run fill ~40 ~40 ~40 ~ ~ ~ $(item) hollow
execute at @p positioned ~ ~ ~ run fill ~38 ~38 ~38 ~ ~ ~ light[level=15]
