scoreboard players reset @p chaos
scoreboard players enable @p chaos

attribute @p minecraft:friction_modifier base set 0
attribute @p minecraft:air_drag_modifier base set 0
attribute @p minecraft:bounciness base set 1
