execute as @p if items entity @s inventory.* stick[minecraft:item_name] run return fail
execute as @p if items entity @s container.* stick[minecraft:item_name] run return fail
execute as @p run loot give @s loot minecraft:flight_stick_give