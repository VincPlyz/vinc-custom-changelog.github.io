scoreboard players reset @p spawn_solid_sulfur
scoreboard players enable @p spawn_solid_sulfur

function triggers/spawn_solid_sulfur with storage minecraft:item