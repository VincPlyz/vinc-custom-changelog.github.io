scoreboard players reset @p spawn_normal_sulfur
scoreboard players enable @p spawn_normal_sulfur

function triggers/spawn_normal_sulfur with storage minecraft:item