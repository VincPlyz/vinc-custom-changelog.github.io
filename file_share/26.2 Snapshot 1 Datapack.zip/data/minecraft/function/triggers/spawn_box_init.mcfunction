scoreboard players reset @p spawn_hollow_box
scoreboard players enable @p spawn_hollow_box

function triggers/spawn_box with storage minecraft:item