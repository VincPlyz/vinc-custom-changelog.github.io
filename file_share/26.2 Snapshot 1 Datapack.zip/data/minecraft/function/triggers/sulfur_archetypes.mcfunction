$execute unless data storage minecraft:item {item:"air"} run execute at @p run execute positioned ~ ~-1 ~ run fill ~100 ~-2 ~100 ~-100 ~ ~-100 $(item)
execute as @p at @p positioned ~-8 ~-1 ~-10 run place template minecraft:custom/sulfur_archetypes

# bouncy (#planks, #logs)

execute at @p positioned ~2 ~2 ~-8 run summon sulfur_cube ~ ~ ~ {equipment:{body:{id:oak_planks}},Size:1,CustomName:'Bouncy'}

# fast_flat (coral, moss, sponge)

execute at @p positioned ~2 ~2 ~-6 run summon sulfur_cube ~ ~ ~ {equipment:{body:{id:sponge}},Size:1,CustomName:'Fast Flat'}

# fast_sliding (blue_ice, packed_ice, snow_block)

execute at @p positioned ~2 ~2 ~-4 run summon sulfur_cube ~ ~ ~ {equipment:{body:{id:blue_ice}},Size:1,CustomName:'Fast Sliding'}

# high_resistance (soul_sand, soul_soil)

execute at @p positioned ~2 ~2 ~-2 run summon sulfur_cube ~ ~ ~ {equipment:{body:{id:soul_sand}},Size:1,CustomName:'High Resistance'}

# light (#wool)

execute at @p positioned ~2 ~2 ~ run summon sulfur_cube ~ ~ ~ {equipment:{body:{id:white_wool}},Size:1,CustomName:'Light'}

# regular (mud, calcite, tuff, more)

execute at @p positioned ~2 ~2 ~2 run summon sulfur_cube ~ ~ ~ {equipment:{body:{id:mud}},Size:1,CustomName:'Regular'}

# slow_flat (copper_block, iron_block, copper_bulb)

execute at @p positioned ~2 ~2 ~4 run summon sulfur_cube ~ ~ ~ {equipment:{body:{id:iron_block}},Size:1,CustomName:'Slow Flat'}

# slow_sliding (shroomlight, #wart_blocks, #mushroom_blocks)

execute at @p positioned ~2 ~2 ~6 run summon sulfur_cube ~ ~ ~ {equipment:{body:{id:shroomlight}},Size:1,CustomName:'Slow Sliding'}

# sticky (honeycomb_block)

execute at @p positioned ~2 ~2 ~8 run summon sulfur_cube ~ ~ ~ {equipment:{body:{id:honeycomb_block}},Size:1,CustomName:'Sticky'}