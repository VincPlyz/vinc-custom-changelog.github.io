tellraw @a {text:"Snapshot Datapack Loaded!",color:green}

# Set Gamerules
gamerule minecraft:max_block_modifications 999999999
gamerule advance_time false
gamerule advance_weather false

tellraw @a {text:"Set Required Gamerules!",color:dark_green}
execute as @p at @p run playsound block.note_block.pling master @p ~ ~ ~ 0.08 2

# Spawn Normal Sulfur Trigger
scoreboard objectives add spawn_normal_sulfur trigger
scoreboard players enable @p spawn_normal_sulfur
trigger spawn_normal_sulfur set 0

# Spawn Normal Invisible Sulfur Trigger
scoreboard objectives add spawn_invisible_sulfur trigger
scoreboard players enable @p spawn_invisible_sulfur
trigger spawn_invisible_sulfur set 0

# Spawn Solid Sulfur Trigger
scoreboard objectives add spawn_solid_sulfur trigger
scoreboard players enable @p spawn_solid_sulfur
trigger spawn_solid_sulfur set 0

# Spawn All Sulfur Archetypes Trigger (Optional Platform when Holding Block)
scoreboard objectives add all_sulfur_archetypes trigger
scoreboard players enable @p all_sulfur_archetypes
trigger all_sulfur_archetypes set 0

# Spawn Hollow Box Trigger
scoreboard objectives add spawn_hollow_box trigger
scoreboard players enable @p spawn_hollow_box
trigger spawn_hollow_box set 0

# Spawn Sulfur and Cinnabar Block Sets
scoreboard objectives add set_block_sets trigger
scoreboard players enable @p set_block_sets
trigger set_block_sets set 0

# Reset Player Attributes Trigger
scoreboard objectives add reset_attributes trigger
scoreboard players enable @p reset_attributes
trigger reset_attributes set 0

# Chaos Trigger
scoreboard objectives add chaos trigger
scoreboard players enable @p chaos
trigger chaos set 0