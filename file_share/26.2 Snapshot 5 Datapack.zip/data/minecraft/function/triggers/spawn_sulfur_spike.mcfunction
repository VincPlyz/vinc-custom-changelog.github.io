scoreboard players reset @p spawn_sulfur_spike
scoreboard players enable @p spawn_sulfur_spike

execute as @p at @p positioned ~4 ~ ~-6 run place template minecraft:custom/sulfur_spike