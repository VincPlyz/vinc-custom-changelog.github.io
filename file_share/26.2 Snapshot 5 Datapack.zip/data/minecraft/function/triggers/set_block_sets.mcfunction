scoreboard players reset @p set_block_sets
scoreboard players enable @p set_block_sets

rotate @p -90 0
execute as @p at @p positioned ~ ~-1 ~-10.5 run place template minecraft:custom/block_sets