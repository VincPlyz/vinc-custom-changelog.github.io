scoreboard players reset @p spawn_geysers
scoreboard players enable @p spawn_geysers

rotate @p 360 0
execute as @p at @p positioned ~-9 ~-4 ~4 run place template minecraft:custom/gay_ser