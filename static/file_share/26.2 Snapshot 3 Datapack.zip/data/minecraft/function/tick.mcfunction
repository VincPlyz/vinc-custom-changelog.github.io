execute if score @p spawn_solid_sulfur matches 1 run function minecraft:triggers/spawn_solid_sulfur_init
execute if score @p spawn_normal_sulfur matches 1 run function minecraft:triggers/spawn_normal_sulfur_init
execute if score @p spawn_invisible_sulfur matches 1 run function minecraft:triggers/spawn_invisible_sulfur_init
execute if score @p all_sulfur_archetypes matches 1 run function minecraft:triggers/sulfur_archetypes_init
execute if score @p spawn_hollow_box matches 1 run function minecraft:triggers/spawn_box_init
execute if score @p set_block_sets matches 1 run function minecraft:triggers/set_block_sets
execute if score @p reset_attributes matches 1 run function minecraft:triggers/reset_attributes
execute if score @p chaos matches 1 run function minecraft:triggers/chaos
execute if score @p spawn_sulfur_spike matches 1 run function minecraft:triggers/spawn_sulfur_spike

execute unless items entity @p weapon.mainhand * run data modify storage minecraft:item item set value air
execute if items entity @p weapon.mainhand * run data modify storage minecraft:item item set from entity @p SelectedItem.id

